#include <vector>
#include <string>
#include "patcher_old.h"

namespace MeshTaichi {
std::string run_mesh(std::string mesh_name, std::vector<std::string> relations);
}