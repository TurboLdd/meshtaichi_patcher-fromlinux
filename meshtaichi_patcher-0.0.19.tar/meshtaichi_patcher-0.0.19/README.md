Some examples can be found under example folder.

### install

```bash
pip install meshtaichi_patcher
```

For users who want to build this repository:

```bash
pip install -r requirements.txt
python3 setup.py develop --user
```
